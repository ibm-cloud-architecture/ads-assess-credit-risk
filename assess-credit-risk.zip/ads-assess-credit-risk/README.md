# Credit application demonstration

The main description of this solution is in [this article](). This repository includes
the IBM Automation Decision Service projects.